# Contacts OTP App

A React application for managing contacts and sending OTP messages.

## Features

- Contact list with search functionality
- Contact details view
- OTP message generation and sending
- Message history with delete functionality
- Dark/light theme toggle
- Responsive design

## Technologies Used

- **React**: Frontend library for building the user interface
- **React Router**: For navigation between different pages
- **Material UI**: Component library for consistent and professional UI
- **Twilio API**: For sending SMS messages
- **LocalStorage**: For persisting sent messages

## Architecture Decisions

1. **Component Structure**: Separated components by functionality (Contacts, Messages, Compose)
2. **State Management**: Used React hooks for state management (useState, useEffect)
3. **Theme Provider**: Implemented a custom theme provider for dark/light mode
4. **Error Handling**: Added comprehensive error handling for API calls and user input
5. **Responsive Design**: Ensured the application works well on different screen sizes

## Setup Instructions

1. Clone the repository
2. Run `npm install` to install dependencies
3. Create a `.env` file with your Twilio credentials:
